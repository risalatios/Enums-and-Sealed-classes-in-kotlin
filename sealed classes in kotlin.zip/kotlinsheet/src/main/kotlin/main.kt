import java.lang.Exception
import java.lang.IllegalArgumentException
import javax.naming.InvalidNameException


fun main(args: Array<String>) {
val result = APIResult.Success(mutableMapOf("name" to "xyzr", "message" to "hello guys"))
    parse(result)
}

// few limitations in case using enum classes in kotlin
//1. kotlin allows only single instance for each value or case
//2. in kotlin we can not carry associated data with each cases
// 3. kotlin enums cant be recursive

sealed class APIResult {
    data class Success(val response: MutableMap<String, String>): APIResult()
    data class Failure(val exception: Exception): APIResult()
    object Loading: APIResult()
}

fun parse(apiResult: APIResult): Unit = when(apiResult) {
    is APIResult.Success -> print(apiResult.response)
    is APIResult.Failure -> print(apiResult.exception.message)
    is APIResult.Loading -> print("Still loading")
}
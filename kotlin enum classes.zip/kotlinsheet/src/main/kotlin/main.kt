import java.lang.Exception
import java.lang.IllegalArgumentException
import javax.naming.InvalidNameException

//#FF0000
//#008000
//#0000FF

fun main(args: Array<String>) {

val currentColor = Color.GREEN

    when(currentColor) {
        Color.RED -> currentColor.printInfo()
        Color.GREEN -> currentColor.printInfo()
        Color.BLUE -> currentColor.printInfo()
    }

    print(Color.values().size)

}

interface PrintColor {
    fun printInfo()
}

enum class Color(val hexCode: String): PrintColor {
    RED("#FF0000") {
        override fun printInfo() {
            println("the hex code for red is ${hexCode}")
        } },
    GREEN("#008000") {
        override fun printInfo() {
            println("the hex code for green is ${hexCode}")
        }
                     },
    BLUE("#0000FF") {
        override fun printInfo() {
            println("the hex code for blue is ${hexCode}")
        }
    }
}